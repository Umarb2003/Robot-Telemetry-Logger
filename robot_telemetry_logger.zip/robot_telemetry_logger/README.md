# Robot Telemetry Logger

A multithreaded C++ telemetry monitoring system that simulates robotic sensor data at 100 Hz, logs operational data, detects anomalies, and generates performance statistics.

## Simulated Signals
- Position x/y
- Velocity x/y
- Temperature
- Motor current
- Battery voltage

## Features
- Producer thread generates robot telemetry at 100 Hz
- Consumer thread logs telemetry to CSV
- Anomaly detector flags overheating, overcurrent, low battery, and high speed
- Statistics module calculates averages, minimums, maximums, and anomaly counts

## Build
```bash
mkdir build
cd build
cmake ..
cmake --build .
./robot_telemetry_logger
```

## Output
- `logs/telemetry.csv`
- `logs/summary.txt`
