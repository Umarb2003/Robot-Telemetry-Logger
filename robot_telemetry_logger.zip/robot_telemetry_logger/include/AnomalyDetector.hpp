#pragma once
#include "TelemetrySample.hpp"

class AnomalyDetector {
public:
    void evaluate(TelemetrySample& sample) const;
};
