#pragma once
#include <string>
#include "TelemetrySample.hpp"

class Statistics {
public:
    void update(const TelemetrySample& sample);
    void writeSummary(const std::string& outputPath) const;

private:
    int count_ = 0;
    int anomalyCount_ = 0;

    double sumTemp_ = 0.0;
    double sumCurrent_ = 0.0;
    double sumBattery_ = 0.0;
    double sumSpeed_ = 0.0;

    double maxTemp_ = -1e9;
    double maxCurrent_ = -1e9;
    double minBattery_ = 1e9;
    double maxSpeed_ = -1e9;
};
