#pragma once
#include <fstream>
#include <string>
#include "TelemetrySample.hpp"
#include "ThreadSafeQueue.hpp"
#include "Statistics.hpp"

class TelemetryLogger {
public:
    TelemetryLogger(ThreadSafeQueue<TelemetrySample>& queue, const std::string& csvPath, const std::string& summaryPath);
    void run();

private:
    ThreadSafeQueue<TelemetrySample>& queue_;
    std::string csvPath_;
    std::string summaryPath_;
    Statistics statistics_;

    void writeHeader(std::ofstream& file);
    void writeSample(std::ofstream& file, const TelemetrySample& sample);
};
