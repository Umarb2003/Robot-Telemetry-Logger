#pragma once
#include <string>

struct TelemetrySample {
    double timestampSeconds{};
    double positionX{};
    double positionY{};
    double velocityX{};
    double velocityY{};
    double temperatureC{};
    double motorCurrentA{};
    double batteryVoltageV{};
    bool anomaly{};
    std::string anomalyReason;
};
