#pragma once
#include "TelemetrySample.hpp"
#include "ThreadSafeQueue.hpp"
#include "AnomalyDetector.hpp"

class TelemetrySimulator {
public:
    TelemetrySimulator(ThreadSafeQueue<TelemetrySample>& queue, int sampleRateHz, int durationSeconds);
    void run();

private:
    ThreadSafeQueue<TelemetrySample>& queue_;
    int sampleRateHz_;
    int durationSeconds_;
    AnomalyDetector detector_;
};
