#include "TelemetryLogger.hpp"
#include <filesystem>
#include <iomanip>
#include <iostream>

TelemetryLogger::TelemetryLogger(ThreadSafeQueue<TelemetrySample>& queue, const std::string& csvPath, const std::string& summaryPath)
    : queue_(queue), csvPath_(csvPath), summaryPath_(summaryPath) {}

void TelemetryLogger::writeHeader(std::ofstream& file) {
    file << "timestamp_s,position_x,position_y,velocity_x,velocity_y,temperature_c,motor_current_a,battery_voltage_v,anomaly,anomaly_reason\n";
}

void TelemetryLogger::writeSample(std::ofstream& file, const TelemetrySample& sample) {
    file << std::fixed << std::setprecision(4)
         << sample.timestampSeconds << ","
         << sample.positionX << ","
         << sample.positionY << ","
         << sample.velocityX << ","
         << sample.velocityY << ","
         << sample.temperatureC << ","
         << sample.motorCurrentA << ","
         << sample.batteryVoltageV << ","
         << sample.anomaly << ","
         << sample.anomalyReason << "\n";
}

void TelemetryLogger::run() {
    std::filesystem::create_directories(std::filesystem::path(csvPath_).parent_path());

    std::ofstream file(csvPath_);
    if (!file) {
        std::cerr << "Could not open CSV file: " << csvPath_ << "\n";
        return;
    }

    writeHeader(file);

    TelemetrySample sample;
    while (queue_.waitPop(sample)) {
        writeSample(file, sample);
        statistics_.update(sample);
    }

    file.close();
    statistics_.writeSummary(summaryPath_);
}
