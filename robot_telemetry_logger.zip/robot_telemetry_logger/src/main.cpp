#include <iostream>
#include <thread>
#include "TelemetrySample.hpp"
#include "ThreadSafeQueue.hpp"
#include "TelemetrySimulator.hpp"
#include "TelemetryLogger.hpp"

int main() {
    constexpr int sampleRateHz = 100;
    constexpr int durationSeconds = 10;

    ThreadSafeQueue<TelemetrySample> queue;
    TelemetrySimulator simulator(queue, sampleRateHz, durationSeconds);
    TelemetryLogger logger(queue, "logs/telemetry.csv", "logs/summary.txt");

    std::thread producer(&TelemetrySimulator::run, &simulator);
    std::thread consumer(&TelemetryLogger::run, &logger);

    producer.join();
    consumer.join();

    std::cout << "Telemetry simulation complete. Check logs/telemetry.csv and logs/summary.txt\n";
    return 0;
}
