#include "TelemetrySimulator.hpp"
#include <chrono>
#include <cmath>
#include <random>
#include <thread>

TelemetrySimulator::TelemetrySimulator(ThreadSafeQueue<TelemetrySample>& queue, int sampleRateHz, int durationSeconds)
    : queue_(queue), sampleRateHz_(sampleRateHz), durationSeconds_(durationSeconds) {}

void TelemetrySimulator::run() {
    using clock = std::chrono::steady_clock;
    const int totalSamples = sampleRateHz_ * durationSeconds_;
    const auto samplePeriod = std::chrono::microseconds(1000000 / sampleRateHz_);

    std::default_random_engine generator(std::random_device{}());
    std::normal_distribution<double> noise(0.0, 0.05);

    double x = 0.0;
    double y = 0.0;

    auto start = clock::now();
    for (int i = 0; i < totalSamples; ++i) {
        double t = static_cast<double>(i) / sampleRateHz_;

        TelemetrySample sample;
        sample.timestampSeconds = t;

        sample.velocityX = 1.0 + 0.2 * std::sin(t) + noise(generator);
        sample.velocityY = 0.5 + 0.1 * std::cos(t) + noise(generator);

        x += sample.velocityX / sampleRateHz_;
        y += sample.velocityY / sampleRateHz_;

        sample.positionX = x;
        sample.positionY = y;
        sample.temperatureC = 45.0 + 8.0 * std::sin(t / 3.0) + noise(generator) * 10.0;
        sample.motorCurrentA = 8.0 + 2.0 * std::sin(t * 2.0) + noise(generator);
        sample.batteryVoltageV = 24.0 - 0.02 * t + noise(generator);

        if (i == totalSamples / 2) {
            sample.temperatureC = 82.0;
            sample.motorCurrentA = 21.0;
        }

        detector_.evaluate(sample);
        queue_.push(sample);

        std::this_thread::sleep_until(start + samplePeriod * (i + 1));
    }

    queue_.close();
}
