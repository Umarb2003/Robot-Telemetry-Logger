#include "Statistics.hpp"
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>

void Statistics::update(const TelemetrySample& sample) {
    ++count_;
    if (sample.anomaly) {
        ++anomalyCount_;
    }

    double speed = std::sqrt(sample.velocityX * sample.velocityX + sample.velocityY * sample.velocityY);

    sumTemp_ += sample.temperatureC;
    sumCurrent_ += sample.motorCurrentA;
    sumBattery_ += sample.batteryVoltageV;
    sumSpeed_ += speed;

    if (sample.temperatureC > maxTemp_) maxTemp_ = sample.temperatureC;
    if (sample.motorCurrentA > maxCurrent_) maxCurrent_ = sample.motorCurrentA;
    if (sample.batteryVoltageV < minBattery_) minBattery_ = sample.batteryVoltageV;
    if (speed > maxSpeed_) maxSpeed_ = speed;
}

void Statistics::writeSummary(const std::string& outputPath) const {
    std::filesystem::create_directories(std::filesystem::path(outputPath).parent_path());
    std::ofstream file(outputPath);

    if (!file || count_ == 0) {
        return;
    }

    file << std::fixed << std::setprecision(3);
    file << "Robot Telemetry Summary\n";
    file << "=======================\n";
    file << "Samples: " << count_ << "\n";
    file << "Anomalies: " << anomalyCount_ << "\n";
    file << "Average temperature C: " << sumTemp_ / count_ << "\n";
    file << "Maximum temperature C: " << maxTemp_ << "\n";
    file << "Average motor current A: " << sumCurrent_ / count_ << "\n";
    file << "Maximum motor current A: " << maxCurrent_ << "\n";
    file << "Average battery voltage V: " << sumBattery_ / count_ << "\n";
    file << "Minimum battery voltage V: " << minBattery_ << "\n";
    file << "Average speed: " << sumSpeed_ / count_ << "\n";
    file << "Maximum speed: " << maxSpeed_ << "\n";
}
