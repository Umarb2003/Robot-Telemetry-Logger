#include "AnomalyDetector.hpp"
#include <cmath>
#include <vector>

void AnomalyDetector::evaluate(TelemetrySample& sample) const {
    std::vector<std::string> reasons;
    double speed = std::sqrt(sample.velocityX * sample.velocityX + sample.velocityY * sample.velocityY);

    if (sample.temperatureC > 75.0) {
        reasons.push_back("OVER_TEMPERATURE");
    }
    if (sample.motorCurrentA > 18.0) {
        reasons.push_back("OVERCURRENT");
    }
    if (sample.batteryVoltageV < 21.0) {
        reasons.push_back("LOW_BATTERY");
    }
    if (speed > 3.0) {
        reasons.push_back("HIGH_SPEED");
    }

    sample.anomaly = !reasons.empty();
    sample.anomalyReason.clear();
    for (size_t i = 0; i < reasons.size(); ++i) {
        sample.anomalyReason += reasons[i];
        if (i + 1 < reasons.size()) {
            sample.anomalyReason += "|";
        }
    }
}
