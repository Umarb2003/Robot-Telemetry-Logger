# Design Notes

## Architecture
- Producer thread: simulates telemetry samples at 100 Hz
- Thread-safe queue: transfers samples between producer and consumer
- Consumer thread: logs data and updates statistics
- Anomaly detector: checks each sample against operating thresholds

## Example Anomaly Conditions
- Temperature above 75 C
- Motor current above 18 A
- Battery voltage below 21 V
- Speed above 3 m/s
